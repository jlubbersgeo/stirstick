# stirstick
the repository for the package stirstick devoted to creating and visualizing geochemical mixtures.

UNDER DEVELOPMENT. Stay tuned.

